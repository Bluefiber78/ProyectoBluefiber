-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 16-02-2023 a las 01:52:06
-- Versión del servidor: 8.0.27
-- Versión de PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `taller`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auto`
--

DROP TABLE IF EXISTS `auto`;
CREATE TABLE IF NOT EXISTS `auto` (
  `id_auto` int NOT NULL AUTO_INCREMENT,
  `id_cliente` varchar(11) NOT NULL,
  `auto_placa` varchar(7) NOT NULL,
  `auto_chasis` varchar(25) NOT NULL,
  `id_marca` int NOT NULL,
  `auto_color` varchar(10) NOT NULL,
  `id_modelo` int NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `auto`
--

INSERT INTO `auto` (`id_auto`, `id_cliente`, `auto_placa`, `auto_chasis`, `id_marca`, `auto_color`, `id_modelo`) VALUES
(1, '0922019377', 'GSI5354', 'zaxscdvfbgqweryt', 1, 'Plomo', 1),
(2, '0907212484', 'GRZ8813', 'qaswdefrgthyzxcbv', 2, 'Dorado', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clasemodelo`
--

DROP TABLE IF EXISTS `clasemodelo`;
CREATE TABLE IF NOT EXISTS `clasemodelo` (
  `clase_id` int NOT NULL AUTO_INCREMENT,
  `clase_nombre` varchar(25) NOT NULL,
  PRIMARY KEY (`clase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `clasemodelo`
--

INSERT INTO `clasemodelo` (`clase_id`, `clase_nombre`) VALUES
(1, 'Automovil'),
(2, 'Camioneta'),
(3, 'Motocicleta'),
(4, 'Furgoneta'),
(5, 'Bus');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clasificacion`
--

DROP TABLE IF EXISTS `clasificacion`;
CREATE TABLE IF NOT EXISTS `clasificacion` (
  `clasificacion_id` int NOT NULL AUTO_INCREMENT,
  `clase_id` int NOT NULL,
  `tipo_id` int NOT NULL,
  PRIMARY KEY (`clasificacion_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `clasificacion`
--

INSERT INTO `clasificacion` (`clasificacion_id`, `clase_id`, `tipo_id`) VALUES
(1, 3, 1),
(2, 3, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 2, 10),
(11, 2, 11),
(12, 4, 12),
(13, 4, 13),
(14, 5, 14),
(15, 5, 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `id_cliente` varchar(13) NOT NULL,
  `nombre_cliente` varchar(30) NOT NULL,
  `apellido_cliente` varchar(30) NOT NULL,
  `direccion_cliente` varchar(50) NOT NULL,
  `telefono_cliente` varchar(10) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id_cliente`, `nombre_cliente`, `apellido_cliente`, `direccion_cliente`, `telefono_cliente`) VALUES
('0907212484', 'Roberto Enrique', 'Vargas Aibar', 'Cdla. Alborada 13ava etapa Mz. 8 Villa 27', '045035495'),
('0922019377', 'Joshua Enrique', 'Valverde Bardellini', 'Cdla. Alborada 13ava etapa Mz. 8 Villa 27', '0990766528');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

DROP TABLE IF EXISTS `marca`;
CREATE TABLE IF NOT EXISTS `marca` (
  `id_marca` int NOT NULL AUTO_INCREMENT,
  `nombre_marca` varchar(50) NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`id_marca`, `nombre_marca`) VALUES
(1, 'Kia'),
(2, 'Chevrolet'),
(3, 'Renault'),
(4, 'Citroem'),
(5, 'Mazda'),
(6, 'BMW'),
(7, 'Toyota'),
(8, 'Mitsubishi'),
(9, 'Audi'),
(10, 'Mercedes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelo`
--

DROP TABLE IF EXISTS `modelo`;
CREATE TABLE IF NOT EXISTS `modelo` (
  `id_modelo` int NOT NULL AUTO_INCREMENT,
  `id_marca` int NOT NULL,
  `nombre_modelo` varchar(50) NOT NULL,
  `clase_id` int NOT NULL,
  `tipo_id` int NOT NULL,
  `id_transmision` int NOT NULL,
  `cilindraje_modelo` varchar(5) NOT NULL,
  `anio_modelo` varchar(5) NOT NULL,
  PRIMARY KEY (`id_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `modelo`
--

INSERT INTO `modelo` (`id_modelo`, `id_marca`, `nombre_modelo`, `clase_id`, `tipo_id`, `id_transmision`, `cilindraje_modelo`, `anio_modelo`) VALUES
(1, 1, 'Rio Stylus', 1, 3, 1, '1500', '2013'),
(2, 1, 'Rio Stylus', 1, 3, 2, '1500', '2013'),
(3, 2, 'Luv D-Max', 2, 11, 1, '2500', '2011'),
(5, 1, 'Sportage AC', 1, 9, 1, '2000', '2017');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `repuestos`
--

DROP TABLE IF EXISTS `repuestos`;
CREATE TABLE IF NOT EXISTS `repuestos` (
  `id_repuesto` int NOT NULL AUTO_INCREMENT,
  `id_modelo` int NOT NULL,
  `repuesto_detalle` varchar(50) NOT NULL,
  `repuesto_costo` float NOT NULL,
  `repuesto_proveedor` varchar(25) NOT NULL,
  `repuesto_observaciones` varchar(50) NOT NULL,
  PRIMARY KEY (`id_repuesto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `nombre_rol` varchar(15) NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre_rol`) VALUES
(1, 'Administrador'),
(2, 'Asistente'),
(3, 'Cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipomodelo`
--

DROP TABLE IF EXISTS `tipomodelo`;
CREATE TABLE IF NOT EXISTS `tipomodelo` (
  `tipo_id` int NOT NULL AUTO_INCREMENT,
  `tipo_nombre` varchar(25) NOT NULL,
  PRIMARY KEY (`tipo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipomodelo`
--

INSERT INTO `tipomodelo` (`tipo_id`, `tipo_nombre`) VALUES
(1, 'Motocicleta'),
(2, 'Cuadron'),
(3, 'Sedan'),
(4, 'Coupe'),
(5, 'Convertible'),
(6, 'Hatchback'),
(7, 'Station Wagon'),
(8, 'Mini Ban'),
(9, 'Suburvan'),
(10, 'Cabina Sencilla'),
(11, 'Doble Cabina'),
(12, 'Furgoneta de Carga'),
(13, 'Furgoneta de Pasajeros'),
(14, 'Microbus'),
(15, 'Minibus');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transmision`
--

DROP TABLE IF EXISTS `transmision`;
CREATE TABLE IF NOT EXISTS `transmision` (
  `id_transmision` int NOT NULL AUTO_INCREMENT,
  `nombre_transmision` varchar(20) NOT NULL,
  PRIMARY KEY (`id_transmision`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `transmision`
--

INSERT INTO `transmision` (`id_transmision`, `nombre_transmision`) VALUES
(1, 'Manual'),
(2, 'Automatica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `usuario_id` varchar(11) NOT NULL,
  `id_rol` int NOT NULL,
  `usuario_pass` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`usuario_id`, `id_rol`, `usuario_pass`) VALUES
('0922019377', 3, '12345'),
('0907212484', 3, '12345'),
('0911111111', 1, '12345');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
